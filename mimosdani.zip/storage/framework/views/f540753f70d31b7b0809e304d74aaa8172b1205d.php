<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('title', 'Admin - Index'); ?>

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Informações úteis</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="card">
            <div class="card-header">
                Acessos
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?php echo e(count($counter)); ?></h3>
                                <p>Acessos ao site</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-fw fa-eye"></i>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?php echo e(count($clicks)); ?></h3>
                                <p>Cliques</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-fw fa-mouse"></i>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mimosdani\resources\views/home.blade.php ENDPATH**/ ?>